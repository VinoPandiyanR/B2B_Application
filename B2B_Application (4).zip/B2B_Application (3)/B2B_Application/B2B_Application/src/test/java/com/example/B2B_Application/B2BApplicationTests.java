package com.example.B2B_Application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class B2BApplicationTests {

	@Test
	void contextLoads() {
	}

}
