package com.example.B2B_Application.service;

import com.example.B2B_Application.entity.CateringOrder;
import com.example.B2B_Application.entity.CateringOrder.OrderStatus;
import com.example.B2B_Application.entity.CateringOrder.PaymentStatus;
import com.example.B2B_Application.entity.Customer;
import com.example.B2B_Application.repository.CateringOrderRepository;
import com.example.B2B_Application.repository.CustomerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class CateringOrderService {
    
    private final CateringOrderRepository orderRepository;
    private final CustomerRepository customerRepository;
    
    public CateringOrderService(CateringOrderRepository orderRepository, CustomerRepository customerRepository) {
        this.orderRepository = orderRepository;
        this.customerRepository = customerRepository;
    }
    
    public CateringOrder createOrder(CateringOrder order, Long customerId) {
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        order.setCustomer(customer);
        order.calculateTotalAmount();
        return orderRepository.save(order);
    }
    
    public CateringOrder updateOrder(Long id, CateringOrder details) {
        CateringOrder order = orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        order.setEventName(details.getEventName());
        order.setEventDate(details.getEventDate());
        order.setNumberOfGuests(details.getNumberOfGuests());
        order.setVenueType(details.getVenueType());
        order.setPricePerPlate(details.getPricePerPlate());
        order.calculateTotalAmount();
        return orderRepository.save(order);
    }
    
    public CateringOrder updateOrderStatus(Long id, OrderStatus status) {
        CateringOrder order = orderRepository.findById(id).orElseThrow(() -> new RuntimeException("Order not found"));
        order.setOrderStatus(status);
        return orderRepository.save(order);
    }
    
    public CateringOrder updatePaymentStatus(Long id, PaymentStatus status) {
        CateringOrder order = orderRepository.findById(id).orElseThrow(() -> new RuntimeException("Order not found"));
        order.setPaymentStatus(status);
        return orderRepository.save(order);
    }
    
    public List<CateringOrder> getAllOrders() { return orderRepository.findAll(); }
    public Optional<CateringOrder> getOrderById(Long id) { return orderRepository.findById(id); }
    public List<CateringOrder> getOrdersByStatus(OrderStatus status) { return orderRepository.findByOrderStatus(status); }
    public List<CateringOrder> getUpcomingOrders() { return orderRepository.findUpcomingOrders(LocalDate.now()); }
    public List<CateringOrder> getRecentOrders() { return orderRepository.findTop10ByOrderByCreatedAtDesc(); }
    public List<CateringOrder> searchOrders(String keyword) { return orderRepository.searchOrders(keyword); }
    public void deleteOrder(Long id) { orderRepository.deleteById(id); }
    public Long getOrderCountByStatus(OrderStatus status) { return orderRepository.countByStatus(status); }
    public long getTotalOrderCount() { return orderRepository.count(); }
    public Double getTotalRevenue() { Double r = orderRepository.getTotalRevenue(); return r != null ? r : 0.0; }
}
