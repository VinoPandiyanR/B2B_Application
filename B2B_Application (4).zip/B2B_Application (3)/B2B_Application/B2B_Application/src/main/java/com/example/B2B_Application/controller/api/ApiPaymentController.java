package com.example.B2B_Application.controller.api;

import com.example.B2B_Application.entity.Payment;
import com.example.B2B_Application.entity.Payment.PaymentMethod;
import com.example.B2B_Application.service.PaymentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin(origins = "*")
public class ApiPaymentController {
    
    private final PaymentService paymentService;
    
    public ApiPaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }
    
    @GetMapping
    public ResponseEntity<List<Payment>> getAllPayments() {
        return ResponseEntity.ok(paymentService.getAllPayments());
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Payment> getPayment(@PathVariable Long id) {
        return paymentService.getPaymentById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    
    @PostMapping
    public ResponseEntity<?> processPayment(@RequestBody Map<String, Object> request) {
        try {
            Long orderId = Long.valueOf(request.get("orderId").toString());
            BigDecimal amount = new BigDecimal(request.get("amount").toString());
            PaymentMethod method = PaymentMethod.valueOf(request.get("paymentMethod").toString());
            String upiId = request.get("upiId") != null ? request.get("upiId").toString() : null;
            return ResponseEntity.ok(paymentService.processPayment(orderId, amount, method, upiId));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
    
    @GetMapping("/total")
    public ResponseEntity<?> getTotalCollected() {
        return ResponseEntity.ok(Map.of("total", paymentService.getTotalCollectedAmount()));
    }
    
    @GetMapping("/methods")
    public ResponseEntity<?> getPaymentMethods() {
        return ResponseEntity.ok(PaymentMethod.values());
    }
}
