package com.example.B2B_Application.service;

import com.example.B2B_Application.entity.CateringOrder;
import com.example.B2B_Application.entity.Payment;
import com.example.B2B_Application.entity.Payment.PaymentMethod;
import com.example.B2B_Application.repository.CateringOrderRepository;
import com.example.B2B_Application.repository.PaymentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class PaymentService {
    
    private final PaymentRepository paymentRepository;
    private final CateringOrderRepository orderRepository;
    
    public PaymentService(PaymentRepository paymentRepository, CateringOrderRepository orderRepository) {
        this.paymentRepository = paymentRepository;
        this.orderRepository = orderRepository;
    }
    
    public Payment processPayment(Long orderId, BigDecimal amount, PaymentMethod method, String upiId) {
        CateringOrder order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        
        Payment payment = new Payment();
        payment.setOrder(order);
        payment.setAmount(amount);
        payment.setPaymentMethod(method);
        payment.setPaymentStatus(Payment.PaymentStatus.SUCCESS);
        payment.setPaymentDate(LocalDateTime.now());
        payment.setUpiId(upiId);
        
        Payment saved = paymentRepository.save(payment);
        
        if (amount.compareTo(order.getFinalAmount()) >= 0) {
            order.setPaymentStatus(CateringOrder.PaymentStatus.COMPLETED);
        } else {
            order.setPaymentStatus(CateringOrder.PaymentStatus.PARTIAL);
        }
        orderRepository.save(order);
        
        return saved;
    }
    
    public List<Payment> getAllPayments() { return paymentRepository.findAll(); }
    public Optional<Payment> getPaymentById(Long id) { return paymentRepository.findById(id); }
    public Optional<Payment> getPaymentByOrderId(Long orderId) { return paymentRepository.findByOrderId(orderId); }
    public List<Payment> getRecentPayments() { return paymentRepository.findTop10ByOrderByCreatedAtDesc(); }
    public Double getTotalCollectedAmount() { Double t = paymentRepository.getTotalCollectedAmount(); return t != null ? t : 0.0; }
}
