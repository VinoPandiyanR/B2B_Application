package com.example.B2B_Application.repository;

import com.example.B2B_Application.entity.CateringOrder;
import com.example.B2B_Application.entity.CateringOrder.OrderStatus;
import com.example.B2B_Application.entity.CateringOrder.PaymentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface CateringOrderRepository extends JpaRepository<CateringOrder, Long> {
    
    Optional<CateringOrder> findByOrderNumber(String orderNumber);
    
    List<CateringOrder> findByCustomerId(Long customerId);
    
    List<CateringOrder> findByOrderStatus(OrderStatus status);
    
    List<CateringOrder> findByPaymentStatus(PaymentStatus status);
    
    List<CateringOrder> findByEventDate(LocalDate eventDate);
    
    List<CateringOrder> findByEventDateBetween(LocalDate startDate, LocalDate endDate);
    
    List<CateringOrder> findByEventManager(String eventManager);
    
    @Query("SELECT o FROM CateringOrder o WHERE o.eventDate >= :today ORDER BY o.eventDate ASC")
    List<CateringOrder> findUpcomingOrders(@Param("today") LocalDate today);
    
    @Query("SELECT o FROM CateringOrder o WHERE o.orderStatus = :status AND o.eventDate >= :today")
    List<CateringOrder> findPendingOrdersFromDate(@Param("status") OrderStatus status, @Param("today") LocalDate today);
    
    @Query("SELECT COUNT(o) FROM CateringOrder o WHERE o.orderStatus = :status")
    Long countByStatus(@Param("status") OrderStatus status);
    
    @Query("SELECT SUM(o.finalAmount) FROM CateringOrder o WHERE o.paymentStatus = 'COMPLETED'")
    Double getTotalRevenue();
    
    @Query("SELECT o FROM CateringOrder o WHERE o.customer.customerName LIKE %:keyword% OR o.orderNumber LIKE %:keyword%")
    List<CateringOrder> searchOrders(@Param("keyword") String keyword);
    
    List<CateringOrder> findTop10ByOrderByCreatedAtDesc();
}

