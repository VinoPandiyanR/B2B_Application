package com.example.B2B_Application.repository;

import com.example.B2B_Application.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
    
    Optional<Customer> findByEmail(String email);
    
    Optional<Customer> findByPhoneNumber(String phoneNumber);
    
    List<Customer> findByCustomerNameContainingIgnoreCase(String name);
    
    List<Customer> findByCompanyNameContainingIgnoreCase(String companyName);
    
    List<Customer> findByCity(String city);
    
    @Query("SELECT c FROM Customer c WHERE c.customerName LIKE %:keyword% OR c.companyName LIKE %:keyword% OR c.email LIKE %:keyword%")
    List<Customer> searchCustomers(@Param("keyword") String keyword);
    
    boolean existsByEmail(String email);
    
    boolean existsByPhoneNumber(String phoneNumber);
}

