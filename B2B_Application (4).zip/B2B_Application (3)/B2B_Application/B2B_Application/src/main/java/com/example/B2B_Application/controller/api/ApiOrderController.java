package com.example.B2B_Application.controller.api;

import com.example.B2B_Application.entity.CateringOrder;
import com.example.B2B_Application.entity.CateringOrder.OrderStatus;
import com.example.B2B_Application.service.CateringOrderService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins = "*")
public class ApiOrderController {
    
    private final CateringOrderService orderService;
    
    public ApiOrderController(CateringOrderService orderService) {
        this.orderService = orderService;
    }
    
    @GetMapping
    public ResponseEntity<List<CateringOrder>> getAllOrders() {
        return ResponseEntity.ok(orderService.getAllOrders());
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<CateringOrder> getOrder(@PathVariable Long id) {
        return orderService.getOrderById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    
    @PostMapping
    public ResponseEntity<CateringOrder> createOrder(@RequestBody Map<String, Object> request) {
        Long customerId = Long.valueOf(request.get("customerId").toString());
        CateringOrder order = new CateringOrder();
        order.setEventName((String) request.get("eventName"));
        order.setEventDate(LocalDate.parse((String) request.get("eventDate")));
        order.setNumberOfGuests(Integer.valueOf(request.get("numberOfGuests").toString()));
        if (request.get("venueType") != null && !request.get("venueType").toString().isEmpty())
            order.setVenueType(CateringOrder.VenueType.valueOf(request.get("venueType").toString()));
        if (request.get("pricePerPlate") != null)
            order.setPricePerPlate(new BigDecimal(request.get("pricePerPlate").toString()));
        if (request.get("eventManager") != null)
            order.setEventManager((String) request.get("eventManager"));
        return ResponseEntity.ok(orderService.createOrder(order, customerId));
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOrder(@PathVariable Long id) {
        orderService.deleteOrder(id);
        return ResponseEntity.ok().build();
    }
    
    @GetMapping("/upcoming")
    public ResponseEntity<List<CateringOrder>> getUpcomingOrders() {
        return ResponseEntity.ok(orderService.getUpcomingOrders());
    }
    
    @GetMapping("/recent")
    public ResponseEntity<List<CateringOrder>> getRecentOrders() {
        return ResponseEntity.ok(orderService.getRecentOrders());
    }
    
    @PutMapping("/{id}/status")
    public ResponseEntity<CateringOrder> updateStatus(@PathVariable Long id, @RequestParam OrderStatus status) {
        return ResponseEntity.ok(orderService.updateOrderStatus(id, status));
    }
    
    @GetMapping("/search")
    public ResponseEntity<List<CateringOrder>> searchOrders(@RequestParam String keyword) {
        return ResponseEntity.ok(orderService.searchOrders(keyword));
    }
    
    @GetMapping("/stats")
    public ResponseEntity<?> getStats() {
        return ResponseEntity.ok(Map.of(
            "totalOrders", orderService.getTotalOrderCount(),
            "pendingOrders", orderService.getOrderCountByStatus(OrderStatus.PENDING),
            "totalRevenue", orderService.getTotalRevenue()
        ));
    }
}
