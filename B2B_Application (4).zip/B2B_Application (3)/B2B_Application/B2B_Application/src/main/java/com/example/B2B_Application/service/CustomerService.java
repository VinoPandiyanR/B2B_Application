package com.example.B2B_Application.service;

import com.example.B2B_Application.entity.Customer;
import com.example.B2B_Application.repository.CustomerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class CustomerService {
    
    private final CustomerRepository customerRepository;
    
    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }
    
    public Customer createCustomer(Customer customer) {
        if (customerRepository.existsByEmail(customer.getEmail())) {
            throw new RuntimeException("Customer with this email already exists");
        }
        return customerRepository.save(customer);
    }
    
    public Customer updateCustomer(Long id, Customer details) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        customer.setCustomerName(details.getCustomerName());
        customer.setCompanyName(details.getCompanyName());
        customer.setEmail(details.getEmail());
        customer.setPhoneNumber(details.getPhoneNumber());
        customer.setAddress(details.getAddress());
        customer.setCity(details.getCity());
        customer.setState(details.getState());
        customer.setPincode(details.getPincode());
        return customerRepository.save(customer);
    }
    
    public List<Customer> getAllCustomers() { return customerRepository.findAll(); }
    public Optional<Customer> getCustomerById(Long id) { return customerRepository.findById(id); }
    public List<Customer> searchCustomers(String keyword) { return customerRepository.searchCustomers(keyword); }
    public void deleteCustomer(Long id) { customerRepository.deleteById(id); }
    public long getCustomerCount() { return customerRepository.count(); }
}
