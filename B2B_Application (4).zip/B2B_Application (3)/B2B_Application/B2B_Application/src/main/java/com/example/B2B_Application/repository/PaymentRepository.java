package com.example.B2B_Application.repository;

import com.example.B2B_Application.entity.Payment;
import com.example.B2B_Application.entity.Payment.PaymentMethod;
import com.example.B2B_Application.entity.Payment.PaymentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {
    
    Optional<Payment> findByTransactionId(String transactionId);
    
    Optional<Payment> findByOrderId(Long orderId);
    
    List<Payment> findByPaymentStatus(PaymentStatus status);
    
    List<Payment> findByPaymentMethod(PaymentMethod method);
    
    List<Payment> findByPaymentDateBetween(LocalDateTime startDate, LocalDateTime endDate);
    
    @Query("SELECT SUM(p.amount) FROM Payment p WHERE p.paymentStatus = 'SUCCESS'")
    Double getTotalCollectedAmount();
    
    @Query("SELECT p FROM Payment p WHERE p.paymentDate >= :startDate AND p.paymentDate <= :endDate AND p.paymentStatus = 'SUCCESS'")
    List<Payment> getPaymentsBetweenDates(@Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate);
    
    List<Payment> findTop10ByOrderByCreatedAtDesc();
}

