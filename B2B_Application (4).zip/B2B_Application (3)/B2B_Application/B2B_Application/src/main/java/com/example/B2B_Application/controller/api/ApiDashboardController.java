package com.example.B2B_Application.controller.api;

import com.example.B2B_Application.entity.CateringOrder.OrderStatus;
import com.example.B2B_Application.service.CateringOrderService;
import com.example.B2B_Application.service.CustomerService;
import com.example.B2B_Application.service.PaymentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
@CrossOrigin(origins = "*")
public class ApiDashboardController {
    
    private final CustomerService customerService;
    private final CateringOrderService orderService;
    private final PaymentService paymentService;
    
    public ApiDashboardController(CustomerService customerService, CateringOrderService orderService, PaymentService paymentService) {
        this.customerService = customerService;
        this.orderService = orderService;
        this.paymentService = paymentService;
    }
    
    @GetMapping("/stats")
    public ResponseEntity<?> getDashboardStats() {
        return ResponseEntity.ok(Map.of(
            "totalCustomers", customerService.getCustomerCount(),
            "totalOrders", orderService.getTotalOrderCount(),
            "pendingOrders", orderService.getOrderCountByStatus(OrderStatus.PENDING),
            "totalRevenue", orderService.getTotalRevenue(),
            "totalCollected", paymentService.getTotalCollectedAmount()
        ));
    }
    
    @GetMapping("/recent-orders")
    public ResponseEntity<?> getRecentOrders() {
        return ResponseEntity.ok(orderService.getRecentOrders());
    }
    
    @GetMapping("/upcoming-events")
    public ResponseEntity<?> getUpcomingEvents() {
        return ResponseEntity.ok(orderService.getUpcomingOrders());
    }
}
